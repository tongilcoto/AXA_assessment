const {Given, When, Then} = require('@cucumber/cucumber');
const expect = require('expect');
const APIRequests = require('./src/apiRequests.js');
const jsonPath = require('jsonpath');

Given(/^I created a new post$/, async () => {
    global.postId = await apiRequests.createPost();
    console.log("POST ID");
    console.log(global.postId);
});

When(/^I create a new comment for the post$/, async () => {
    global.comment = {
        postId: global.postId,
        name: 'bar',
        email: 'tonhito@pruebas.com',
        body: 'le llamaban body by Keanu Reaves'
      }
    global.commentId = await apiRequests.createComment(global.postId, global.comment);
    console.log("COMMENT ID");
    console.log(global.commentId)
});

Then(/^the comment is created in the post$/, async () => {
    // USING PROVIDER CONSOLIDATED DATA
    global.postId = 99
    global.commentId = 494
    global.comment = {
        postId: global.postId,
        name: 'molestias facere soluta mollitia totam dolorem commodi itaque',
        email: 'Kadin@walter.io',
        body: 'est illum quia alias ipsam minus\nut quod vero aut magni harum quis\nab minima voluptates nemo non sint quis\ndistinctio officia ea et maxime',
        id: global.commentId
      }
    const comment = await apiRequests.getCommentForPost(global.postId, global.commentId);
    console.log("CREATED COMMENT");
    console.log(comment);
    expect(comment).toEqual(global.comment);
});

Given(/^I have this json object$/, (jsonObject) => {
    global.jsonObject = JSON.parse(jsonObject);
});

When(/^I look for "(deviceId)" extension value$/, (extensionAttribute) => {
    global.extensionAttribute = `$..extension[?(@.url=="${extensionAttribute}")].valueId`;
});

Then(/^I get "(deviceId1)"$/, (attributeValue) => {
    console.log(global.extensionAttribute);
    const data = jsonPath.query(global.jsonObject, global.extensionAttribute)[0];
    console.log(data);
    expect(data).toEqual(attributeValue);
});

Given(/^I have the following body$/, (bodyTable) => {
    global.body = bodyTable.rowsHash()
});

Given(/^I make a POST call to the following endpoint "(\/api\/v3\/addItem)"$/, async (endpoint) => {
    // FAKE FUNCTION CALLING ...
    global.response = await apiRequests.sendPOST(endpoint, global.body)
});

Then(/^the response is 200$/, () => {
  expect(global.response.status).toEqual(200)
});

Then(/^the following values are present$/, async (responseTable) => {
  expect(await global.response.json()).toMatchObject(responseTable.rowsHash())
});