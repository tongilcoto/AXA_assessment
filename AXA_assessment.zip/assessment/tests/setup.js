const apiRequests = require('./src/apiRequests.js');
global.apiRequests = new apiRequests();