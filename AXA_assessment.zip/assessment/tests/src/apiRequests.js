const fetch = require("node-fetch"); 


class APIRequests {

    async createPost() {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
            method: 'POST',
            body: JSON.stringify({
              title: 'foo',
              body: 'bar',
              userId: 1,
            }),
            headers: {
              'Content-type': 'application/json; charset=UTF-8',
            },
        });

        const data = await response.json();

        return data.id;
    }

    async getPost(postId) {
        const response = await fetch(`https://jsonplaceholder.typicode.com/posts/${postId}`);

        const data = await response.json();

        return data;
    }

    async deletePost(postId) {
        const response = await fetch(`https://jsonplaceholder.typicode.com/posts/${postId}`, {method: 'DELETE'});
    }

    async createComment(postId, comment) {
        const response = await fetch('https://jsonplaceholder.typicode.com/comments', {
            method: 'POST',
            body: JSON.stringify(comment),
            headers: {
              'Content-type': 'application/json; charset=UTF-8',
            },
        });

        const data = await response.json();

        return data.id;
    }

    async getCommentForPost(postId, commentId) {
        const response = await fetch(`https://jsonplaceholder.typicode.com/posts/${postId}/comments`);

        const data = await response.json();

        return data.filter(comment => comment.id === commentId)[0];

    }

    async deleteComment(commentId) {
        const response = await fetch(`https://jsonplaceholder.typicode.com/comments/${commentId}`, {method: 'DELETE'});
    }

};

module.exports = APIRequests;