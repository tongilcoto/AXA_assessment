const {After} = require('@cucumber/cucumber');

// Since it is a data clean up after the test is finished, I decided to use cucumber hooks filtered by tags
// in order to know when the clean up is needed
After({tags: "@newPost and @newComment"}, async () => {
    apiRequests.deleteComment(global.commentId);
    apiRequests.deletePost(global.postId)
    const postId = await apiRequests.getPost(global.postId);
    console.log("POST ID ALIVE")
    // Since it is fake data there is no way to verify the deletion
    console.log(postId.id)
});